
class addEH {allowedTargets=0;};
class armedLoop  {allowedTargets=0;};
class compromised {allowedTargets=0;};
class cooldown {allowedTargets=0;};
class isKnownExact {allowedTargets=0;};
class gearHandler {allowedTargets=0;};
class getConfigInfo {allowedTargets=0;};
class isKnownToSide {allowedTargets=0;};
class initUcrVars {allowedTargets=0;};
class recruitHandler {allowedTargets=0;};
class suspiciousEny {allowedTargets=0;};
class UCRhandler {allowedTargets=0;};
class ucrMain {allowedTargets=0;};
